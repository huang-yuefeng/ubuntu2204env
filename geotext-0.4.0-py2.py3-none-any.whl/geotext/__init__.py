# -*- coding: utf-8 -*-

__author__ = 'Yaser Martinez Palenzuela'
__email__ = 'yaser.martinez@gmail.com'
__version__ = '0.2.0'

from .geotext import GeoText